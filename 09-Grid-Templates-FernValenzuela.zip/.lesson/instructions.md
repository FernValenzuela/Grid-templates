# Instructions  

--- 

Hint: since the children elements all have specified heights,
you should use grid-auto-rows.

Edit the 'style.css' file to create this format using grid
template areas:
![Screenshot](./assets/Screenshot.png)